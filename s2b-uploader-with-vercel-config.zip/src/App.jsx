import React, { useState } from "react";
import axios from "axios";

function App() {
  const [product, setProduct] = useState({ name: "", price: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`상품명: ${product.name}, 가격: ${product.price}`);
    // 실제 등록 로직은 S2B API 또는 자동화 프로세스 필요
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>S2B 자동 상품 등록기</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>상품명: </label>
          <input
            type="text"
            value={product.name}
            onChange={(e) => setProduct({ ...product, name: e.target.value })}
          />
        </div>
        <div>
          <label>가격: </label>
          <input
            type="number"
            value={product.price}
            onChange={(e) => setProduct({ ...product, price: e.target.value })}
          />
        </div>
        <button type="submit" style={{ marginTop: "1rem" }}>
          등록하기
        </button>
      </form>
    </div>
  );
}

export default App;
